// Questao 4 - Produto com desconto//
#include<stdio.h>

int main(){

    int value,desconto;
    float total;

    printf("informe o valor do produto");
    scanf("%d",&value);
    
    printf("Informe o valor com o desconto(maximo de 100)");
    scanf("%d",&desconto);

        total = value - (value * desconto / 100 );
        //valor em porcentagem///
    

    printf("O valor do seu produto com desconto e de %f",total);

    return 0;
}