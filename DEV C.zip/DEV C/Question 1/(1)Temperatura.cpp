// Questao 2 - Salario com horas extras//
#include<stdio.h>

int main(){

    int salarioBase, extra;
    float salarioTotal;

    printf("Insira o salario base:");
    scanf("%d",&salarioBase);

    printf("Insira as horas acumuladas:");
    scanf("%d",&extra);

        salarioTotal = ( extra * 100 ) + salarioBase;
        //sim, ele ganha 100 pela hora extra//

    printf("O salario total (com horas acumuladas) foi de: $%f",salarioTotal);

    return 0;
}