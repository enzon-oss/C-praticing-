#include<stdio.h>

int main(){

    int pecas;
    float total;    

        printf("Se 8 maquinas produzem 120 pecas em 5 horas...");

            pecas = 120;
            total = pecas * 10 / 8;
            //o calculo foi feito com base na regra de 3, como o tempo é o mesmo desconsiderei e fiz//
            //8 - 120//
            //10 - x//
            //8x = 120 x 10// 
            

        printf("10 maquinas trabalhando nas mesmas 5 horas na mesma intensidade produzirao %f", total);

    return 0;
}